<?php
error_reporting(0);  
// 检测PHP环境
define('DEBUG',true);
error_reporting(E_ALL);

// if(!$_COOKIE['iwedebug_20160808']) {
	// echo '<!Doctype html><html><head><meta http-equiv=Content-Type content="text/html;charset=utf-8">';
	// exit('系统升级中，预计今晚22时完成，给您带来的不便敬请谅解~');
// }

if(version_compare(PHP_VERSION, '5.3.0','<'))  die('require PHP > 5.3.0 !');

define('DS', DIRECTORY_SEPARATOR);  
// 站点目录
define('SITE_DIR', dirname(__FILE__));
// 站点地址
define('SCRIPT_DIR', rtrim(dirname($_SERVER['SCRIPT_NAME']), '\/\\'));
define('SITE_URL', $_SERVER['HTTP_HOST'] . SCRIPT_DIR);
//来源页面
define('HTTP_REFERER', isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '');
//文件上传根目录
define('UPLOAD_PATH', './Public/upload/');
//附件上传根目录
define('ATTACHMENT_PATH', './Public/Attachment/');

// 开启调试模式 建议开发阶段开启 部署阶段注释或者设为false
define('APP_DEBUG', true);

// 定义应用目录
define('APP_PATH','./Application/');
// 引入ThinkPHP入口文件
require './ThinkPHP/ThinkPHP.php';

// 亲^_^ 后面不需要任何代码了 就是如此简单