<?php
/*
UploadiFive
Copyright (c) 2012 Reactive Apps, Ronnie Garcia
*/

$temp  = explode('.php',$_SERVER['PHP_SELF']);
$PHP_FILE = rtrim(str_replace($_SERVER['HTTP_HOST'],'',$temp[0].'.php'),'/');
$Root_Path  =   rtrim(dirname($PHP_FILE),'/');


date_default_timezone_set('Asia/Shanghai');
// Set the uplaod directory

$folder = $_POST['file'];
if(is_null($folder)) {
	echo '-1';
	exit();
}
$baseDir = $Root_Path . '/uploads/' . $folder . '/';
$_time = time();
$verifyToken = md5('amed' . $_POST['timestamp']);

if($folder == 'thumb') {
	$fileTypes = array('jpg', 'jpeg', 'gif', 'png'); // Allowed file extensions
	if (!empty($_FILES) && $_POST['token'] == $verifyToken) {
		$tempFile   = $_FILES['Filedata']['tmp_name'];
		$uploadDir  = $_SERVER['DOCUMENT_ROOT'] . $baseDir . date('Ym', $_time) . '/';
		if(!is_dir($uploadDir)) mkdir($uploadDir, 0777);
		//$targetFile = $uploadDir . $_FILES['Filedata']['name'];
		
		$fileParts = pathinfo($_FILES['Filedata']['name']);
		$fileExtension = strtolower($fileParts['extension']);
		$file_url = '/' . date('YmdHis', $_time) . '_' . rand(100000, 999999) . '.' . $fileExtension;
		// $file_url = '/' . date('YmdHis', $_time) . '_' . rand(100000, 999999) . '.' . $fileParts['extension'];
		$targetFile = rtrim($uploadDir, '/') . $file_url;
		
		if (in_array($fileExtension, $fileTypes)) {
			move_uploaded_file($tempFile, $targetFile);
			list($width_orig,$height_orig) = getimagesize($targetFile);
			if($width_orig > 640){
				_uploadifive_thumb($targetFile, 640, $fileExtension);
			}
			echo $baseDir . date('Ym', $_time) . $file_url;
		} else {
			echo '-2';
		}
	}
} else if($folder == 'video') {
	$fileTypes = array('mp4', 'avi', 'wmv'); // Allowed file extensions
	if (!empty($_FILES) && $_POST['token'] == $verifyToken) {
		$tempFile   = $_FILES['Filedata']['tmp_name'];
		$uploadDir  = $_SERVER['DOCUMENT_ROOT'] . $baseDir . date('Ym', $_time) . '/';
		if(!is_dir($uploadDir)) mkdir($uploadDir, 0777);
		//$targetFile = $uploadDir . $_FILES['Filedata']['name'];
		
		$fileParts = pathinfo($_FILES['Filedata']['name']);
		$fileExtension = strtolower($fileParts['extension']);
		$file_url = '/' . date('YmdHis', $_time) . '_' . rand(100000, 999999) . '.' . $fileExtension;
		// $file_url = '/' . date('YmdHis', $_time) . '_' . rand(100000, 999999) . '.' . $fileParts['extension'];
		$targetFile = rtrim($uploadDir, '/') . $file_url;
		
		if (in_array($fileExtension, $fileTypes)) {
			move_uploaded_file($tempFile, $targetFile);
			echo $baseDir . date('Ym', $_time) . $file_url;
		} else {
			echo '-2';
		}
	}
} else if($folder == 'profile') {
	$fileTypes = array('ppt', 'pptx', 'doc', 'docx', 'pdf', 'xls', 'xlsx', 'jpg', 'jpeg', 'png', 'gif'); // Allowed file extensions
	if (!empty($_FILES) && $_POST['token'] == $verifyToken) {
		$tempFile   = $_FILES['Filedata']['tmp_name'];
		$uploadDir  = $_SERVER['DOCUMENT_ROOT'] . $baseDir . date('Ym', $_time) . '/';
		if(!is_dir($uploadDir)) mkdir($uploadDir, 0777);
		//$targetFile = $uploadDir . $_FILES['Filedata']['name'];
		
		$fileParts = pathinfo($_FILES['Filedata']['name']);
		$fileExtension = strtolower($fileParts['extension']);
		$file_url = '/' . date('YmdHis', $_time) . '_' . rand(100000, 999999) . '.' . $fileExtension;
		// $file_url = '/' . date('YmdHis', $_time) . '_' . rand(100000, 999999) . '.' . $fileParts['extension'];
		$targetFile = rtrim($uploadDir, '/') . $file_url;
		
		if (in_array($fileExtension, $fileTypes)) {
			move_uploaded_file($tempFile, $targetFile);
			echo $baseDir . date('Ym', $_time) . $file_url . '|' . $_FILES['Filedata']['name'] . '|' . $fileExtension;
		} else {
			echo '-2';
		}
	}
}

//用于对图片进行缩放
function _uploadifive_thumb($filename, $width = 0, $ext) {
	//获取原图像$filename的宽度$width_orig和高度$height_orig
	list($width_orig, $height_orig) = getimagesize($filename);
	//根据参数$width和$height值，换算出等比例缩放的高度和宽度
	if ($width && ($width_orig > 640)) {
		$width = 640;
		$height = ($width * $height_orig) / $width_orig;
	}
	//将原图缩放到这个新创建的图片资源中
	$image_p = imagecreatetruecolor($width, $height);
	//获取原图的图像资源
	if($ext == 'jpg' || $ext == 'jpeg') {
		$image = imagecreatefromjpeg($filename);
	}else if($ext == 'png'){
		$image =  imagecreatefrompng( $filename );
	}else if($ext == 'gif'){
		$image =  imagecreatefromgif( $filename );
	}
	//使用imagecopyresampled()函数进行缩放设置
	imagecopyresampled($image_p,$image,0,0,0,0,$width,$height,$width_orig,$height_orig);
	//将缩放后的图片$image_p保存，100(质量最佳，文件最大)
	if($ext == 'jpg' || $ext == 'jpeg'){
		imagejpeg($image_p,$filename);
	}else if($ext == 'png'){
		imagepng($image_p,$filename);
	}else if($ext == 'gif'){
		imagegif($image_p,$filename);
	}
	imagedestroy($image_p);
	imagedestroy($image);
}